<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', 'ITFit');
   define('DB_DATABASE', 'itfit');
?>